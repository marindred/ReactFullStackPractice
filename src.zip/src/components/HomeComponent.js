import React  from "react";
import { useNavigate } from "react-router-dom";

const HomeComponent = () => {
const navigate = useNavigate();
const employee = () => {
    navigate("/employees");
}
const products = () => {
    navigate("/products");
}


  return (
    <div style = {{textAlign:"center", width:"100%"}}>
        <button className="btn btn-primary" style={{width:"100%"}} onClick= {employee}>Employee Manager</button><br/>
        <button className="btn btn-primary" style={{width:"100%"}} onClick = {products}>Product Manager</button>
    </div>
  )
}
export default HomeComponent;
